package com.inx.materialedittext;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;



public class MaterialEditText extends FrameLayout {

    /*Default Colors and Backgrounds*/
    public static int DEFAULT_TEXT_COLOR = Color.parseColor("#4A4A4A");
    public static int DEFAULT_LABEL_COLOR = Color.parseColor("#000000");
    public static int DEFAULT_HINT_COLOR = Color.parseColor("#888888");
    public static int DEFAULT_ERROR_COLOR = Color.parseColor("#FF0000");
    public static int DEFAULT_BORDER = R.drawable.input_text_back_field;
    public static int DEFAULT_BORDER_ERROR = R.drawable.bg_rounded_error_input_field;
    public static int DEFAULT_ERROR_TEXT_VISIBILITY = 1;
    public static int DEFAULT_INPUT_TYPE = 0;
    public static int DEFAULT_RIGHT_IMAGE_VISIBILITY = 0;

    public static float DEFAULT_TEXT_SIZE = 14;
    public static float DEFAULT_LABEL_TEXT_SIZE = 14;
    public static float DEFAULT_ERROR_TEXT_SIZE = 14;
    public static boolean DEFAULT_TEXT_ENABLED = true;
    public static int DEFAULT_CHAR_LENGTH = 99999;


    public static enum VISIBILITY {VISIBLE, INVISIBLE, GONE}

    public static enum INPUT_TYPE {text, textMultiLine, textEmailAddress, phone, number, numberPassword, textPassword}



    /*Default Values*/

    public static String DEFAULT_TEXT = "";
    public static String DEFAULT_LABEL = "label";
    public static String DEFAULT_HINT = "Hint";
    public static String DEFAULT_ERROR_TEXT = "Invalid Input";
    public static int DEFAULT_DRAWABLE = R.drawable.icn_user;


    String text = DEFAULT_TEXT;
    int textColor = DEFAULT_TEXT_COLOR;

    String labelText = DEFAULT_LABEL;
    int labelColor = DEFAULT_LABEL_COLOR;

    String hintText = DEFAULT_HINT;
    int hintColor = DEFAULT_HINT_COLOR;

    String errorText = DEFAULT_ERROR_TEXT;
    int errorTextColor = DEFAULT_ERROR_COLOR;


    int border = DEFAULT_BORDER;
    int errorBorder = DEFAULT_BORDER_ERROR;

    int drawableId = DEFAULT_DRAWABLE;
    int errorTextVisibility = DEFAULT_ERROR_TEXT_VISIBILITY;
    int inputType = DEFAULT_INPUT_TYPE;

    int rightImageVisibility = DEFAULT_RIGHT_IMAGE_VISIBILITY;

    float textSize = DEFAULT_TEXT_SIZE;
    float labelTextSize = DEFAULT_LABEL_TEXT_SIZE;
    float errorTextSize = DEFAULT_ERROR_TEXT_SIZE;
    boolean isTextEnabled = DEFAULT_TEXT_ENABLED;
    int maxChar = DEFAULT_CHAR_LENGTH;

    /*UI Widgets*/
    EditText input_et;
    TextView label_tv, error_tv;
    LinearLayout inputLayout_ll;
    ImageView rightImage_iv;

    TextChangeListener textChangeListener;

    public MaterialEditText(@NonNull Context context) {
        super(context);
    }

    public MaterialEditText(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context, attrs);
    }

    public MaterialEditText(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        //initView(context, attrs);
    }

    public MaterialEditText(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public void initView(Context context, AttributeSet attrs) {

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.EditText);

        /*Text input*/
        inputType = a.getInt(R.styleable.EditText_inputType, DEFAULT_INPUT_TYPE);
        text = a.getString(R.styleable.EditText_textInput);
        textColor = a.getColor(R.styleable.EditText_textColor, DEFAULT_TEXT_COLOR);

        /*Label Text*/
        labelText = a.getString(R.styleable.EditText_label);
        labelColor = a.getColor(R.styleable.EditText_labelColor, DEFAULT_LABEL_COLOR);

        /*Hint Text*/
        hintText = a.getString(R.styleable.EditText_hint);
        hintColor = a.getColor(R.styleable.EditText_hintColor, DEFAULT_HINT_COLOR);

        /*Error Text */
        errorText = a.getString(R.styleable.EditText_error);
        errorTextColor = a.getColor(R.styleable.EditText_errorColor,
                DEFAULT_ERROR_COLOR);

        /* Border Resource */
        border = a.getResourceId(R.styleable.EditText_border, DEFAULT_BORDER);
        errorBorder = a.getResourceId(R.styleable.EditText_errorBorder,
                DEFAULT_BORDER_ERROR);

        /*Right Image*/
        drawableId = a.getResourceId(R.styleable.EditText_imgSrc, DEFAULT_DRAWABLE);
        errorTextVisibility = a.getInt(R.styleable.EditText_errorVisible,
                DEFAULT_ERROR_TEXT_VISIBILITY);
        rightImageVisibility = a.getInt(R.styleable.EditText_icnVisible,
                DEFAULT_RIGHT_IMAGE_VISIBILITY);

        textSize = a.getDimension(R.styleable.EditText_textSize, DEFAULT_TEXT_SIZE);
        errorTextSize = a.getDimension(R.styleable.EditText_errorTextSize,
                DEFAULT_ERROR_TEXT_SIZE);
        labelTextSize = a.getDimension(R.styleable.EditText_labelTextSize,
                DEFAULT_LABEL_TEXT_SIZE);

        isTextEnabled = a.getBoolean(R.styleable.EditText_enabled, DEFAULT_TEXT_ENABLED);
        maxChar = a.getInteger(R.styleable.EditText_maxLength, DEFAULT_CHAR_LENGTH);


        a.recycle();

        addView(context);
    }


    /**
     * Add Text Input Layout to Parent View (Frame Layout)
     *
     * @param context
     */
    public void addView(Context context) {

        View view = LayoutInflater.from(getContext()).inflate(R.layout.layout_edittext, this,
                false);



        input_et = (EditText) view.findViewById(R.id.input_text);
        input_et.addTextChangedListener(new MyTextWatcher(input_et));
        inputLayout_ll = (LinearLayout) view.findViewById(R.id.text_input_layout);
        label_tv =  view.findViewById(R.id.label_text);
        error_tv =  view.findViewById(R.id.error_text);
        rightImage_iv = (ImageView) view.findViewById(R.id.right_image);

        /*Set input from XML*/
        if (inputType == 0)
            input_et.setInputType(InputType.TYPE_CLASS_TEXT);
        else if (inputType == 1)
            input_et.setInputType(InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        else if (inputType == 2)
            input_et.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        else if (inputType == 3)
            input_et.setInputType(InputType.TYPE_CLASS_PHONE);
        else if (inputType == 4)
            input_et.setInputType(InputType.TYPE_CLASS_NUMBER);
        else if (inputType == 5)
            input_et.setInputType(InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        else if (inputType == 6)
            input_et.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);


        input_et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxChar)});
        input_et.setEnabled(isTextEnabled);

        input_et.setText(text);
        input_et.setTextColor(textColor);
        input_et.setHint(hintText);
        input_et.setHintTextColor(hintColor);
        inputLayout_ll.setBackgroundResource(border);
        label_tv.setText(labelText);
        label_tv.setTextColor(labelColor);
        error_tv.setText(errorText);
        error_tv.setTextColor(errorTextColor);
        rightImage_iv.setImageResource(drawableId);
        if (errorTextVisibility == 0) {
            error_tv.setVisibility(VISIBLE);
        } else if (errorTextVisibility == 1) {
            error_tv.setVisibility(INVISIBLE);
        } else {
            error_tv.setVisibility(GONE);
        }

        if (rightImageVisibility == 0) {
            rightImage_iv.setVisibility(VISIBLE);
        } else if (rightImageVisibility == 1) {
            rightImage_iv.setVisibility(INVISIBLE);

        } else {
            rightImage_iv.setVisibility(GONE);
        }
        /*Set Text Size*/
        input_et.setTextSize(textSize);
        label_tv.setTextSize(labelTextSize);
        error_tv.setTextSize(errorTextSize);

        this.addView(view);

        invalidate();
    }


    /**
     * Text Watcher class
     */
    private class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (textChangeListener != null)
                textChangeListener.beforeTextChanged(charSequence);
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (textChangeListener != null)
                textChangeListener.onTextChanged(charSequence);
        }

        public void afterTextChanged(Editable editable) {
            if (textChangeListener != null)
                textChangeListener.afterTextChanged(editable);
        }

    }

    /**
     * Text Change Listener
     */
    public interface TextChangeListener {
        public void beforeTextChanged(CharSequence charSequence);

        public void onTextChanged(CharSequence charSequence);

        public void afterTextChanged(Editable editable);
    }

    /**
     * Set Text Change Listener
     *
     * @param textChangeListener
     */

    public void setOnTextChangeListener(TextChangeListener textChangeListener) {
        this.textChangeListener = textChangeListener;
    }


    public String getText() {
        String text = "";
        if (input_et != null)
           text=input_et.getText().toString();
        return text;

    }


    /**
     * set Text Input
     *
     * @param text
     */
    public void setText(String text) {
        if (input_et != null)
            input_et.setText(text);
    }

    /**
     * set Hint Text
     *
     * @param hint
     */
    public void setHint(String hint) {
        if (input_et != null)
            input_et.setHint(hint);
    }


    /**
     * set Text Color
     *
     * @param colorId
     */
    public void setTextColor(int colorId) {
        if (input_et != null)
            input_et.setTextColor(colorId);
    }

    /**
     * set Hint Color
     *
     * @param colorId
     */
    public void setHintColor(int colorId) {
        if (input_et != null)
            input_et.setHintTextColor(colorId);
    }

    /**
     * set Label Color
     *
     * @param label
     */
    public void setLabel(String label) {
        if (label_tv != null)
            label_tv.setText(label);
    }

    /**
     * set Label Color
     *
     * @param labelColor
     */
    public void setLabelColor(int labelColor) {
        if (label_tv != null)
            label_tv.setTextColor(labelColor);
    }

    /**
     * set Error Message
     *
     * @param error
     */
    public void setError(String error) {
        if (error_tv != null)
            error_tv.setText(error);

    }

    public void setErrorColor(int colorId) {
        if (error_tv != null)
            error_tv.setTextColor(colorId);
    }

    /**
     * set border
     *
     * @param borderId
     */
    public void setBorder(int borderId) {
        if (inputLayout_ll != null)
            inputLayout_ll.setBackgroundResource(borderId);
    }

    /**
     * set drable border
     *
     * @param drawable
     */
    public void setBorder(Drawable drawable) {
        if (inputLayout_ll != null)
            inputLayout_ll.setBackgroundDrawable(drawable);
    }

    /**
     * set Error Visibility
     *
     * @param visibility
     */
    public void setErrorVisibility(VISIBILITY visibility) {
        if (visibility == VISIBILITY.VISIBLE) {
            if (error_tv != null)
                error_tv.setVisibility(VISIBLE);
        } else if (visibility == VISIBILITY.INVISIBLE) {
            if (error_tv != null)
                error_tv.setVisibility(INVISIBLE);
        } else if (visibility == VISIBILITY.GONE) {
            if (error_tv != null)
                error_tv.setVisibility(GONE);
        }
    }

    public int getRightImageVisibility() {
        return rightImageVisibility;
    }

    public void setRightImageVisibility(VISIBILITY visibility) {
        if (visibility == VISIBILITY.VISIBLE) {
            if (rightImage_iv != null)
                rightImageVisibility = 0;
            rightImage_iv.setVisibility(VISIBLE);
        } else if (visibility == VISIBILITY.INVISIBLE) {
            if (rightImage_iv != null)
                rightImage_iv.setVisibility(INVISIBLE);
            rightImageVisibility = 1;
        } else if (visibility == VISIBILITY.GONE) {
            if (rightImage_iv != null)
                rightImage_iv.setVisibility(GONE);
            rightImageVisibility = 2;
        }
    }


    /**
     * Set Input Type
     *
     * @param inputType
     */

    public void setInputType(INPUT_TYPE inputType) {
        if (inputType == INPUT_TYPE.text) {
            input_et.setInputType(InputType.TYPE_CLASS_TEXT);
            this.inputType = 0;
        } else if (inputType == INPUT_TYPE.textMultiLine) {
            this.inputType = 1;
            input_et.setInputType(InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        } else if (inputType == INPUT_TYPE.textEmailAddress) {
            this.inputType = 2;
            input_et.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        } else if (inputType == INPUT_TYPE.phone) {
            this.inputType = 3;
            input_et.setInputType(InputType.TYPE_CLASS_PHONE);
        } else if (inputType == INPUT_TYPE.number) {
            this.inputType = 4;
            input_et.setInputType(InputType.TYPE_CLASS_NUMBER);
        } else if (inputType == INPUT_TYPE.numberPassword) {

            this.inputType = 5;
            input_et.setInputType(InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        } else if (inputType == INPUT_TYPE.textPassword) {
            this.inputType = 6;
            input_et.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);

        }

    }


    /**
     * set Right Image
     *
     * @param imageId
     */
    public void setRightImage(int imageId) {
        if (rightImage_iv != null)
            rightImage_iv.setImageResource(imageId);
    }

    /**
     * Set Drawable Right Image
     *
     * @param drawable
     */
    public void setRightImage(Drawable drawable) {
        if (rightImage_iv != null)
            rightImage_iv.setImageDrawable(drawable);
    }


    public static int getDefaultTextColor() {
        return DEFAULT_TEXT_COLOR;
    }

    public static void setDefaultTextColor(int defaultTextColor) {
        DEFAULT_TEXT_COLOR = defaultTextColor;
    }

    public float getTextSize() {
        return textSize;
    }

    public void setTextSize(float textSize) {
        this.textSize = textSize;
        input_et.setTextSize(textSize);
    }

    public float getLabelTextSize() {
        return labelTextSize;
    }

    public void setLabelTextSize(float labelTextSize) {
        this.labelTextSize = labelTextSize;
        label_tv.setTextSize(labelTextSize);
    }

    public float getErrorTextSize() {
        return errorTextSize;
    }

    public void setErrorTextSize(float errorTextSize) {
        this.errorTextSize = errorTextSize;
        error_tv.setTextSize(errorTextSize);
    }

    public void setMaxLength(int maxLength) {
        this.maxChar = maxLength;
        input_et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});

    }

    public void setEnabled(boolean isTextEnabled) {
        this.isTextEnabled = isTextEnabled;
        input_et.setEnabled(isTextEnabled);
    }

    public boolean getEnabled() {
        return this.isTextEnabled;
    }

    public int getMaxLength() {
        return this.maxChar;
    }
}
