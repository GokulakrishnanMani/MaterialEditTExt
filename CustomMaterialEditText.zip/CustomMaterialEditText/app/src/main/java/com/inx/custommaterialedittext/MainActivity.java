package com.inx.custommaterialedittext;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.widget.Toast;

import com.inx.materialedittext.MaterialEditText;

public class MainActivity extends AppCompatActivity {
MaterialEditText editText;
String TAG= "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

    }
   public void initView()
    {
       editText=(MaterialEditText)findViewById(R.id.editText);
       editText.setOnTextChangeListener(new MaterialEditText.TextChangeListener() {
           @Override
           public void beforeTextChanged(CharSequence charSequence) {

           }

           @Override
           public void onTextChanged(CharSequence charSequence) {

               Log.i(TAG,charSequence.toString());
           }

           @Override
           public void afterTextChanged(Editable editable) {

           }
       });
    }
}
